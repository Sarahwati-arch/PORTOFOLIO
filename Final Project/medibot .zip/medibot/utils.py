# Fungsi untuk memvalidasi format waktu (HH:MM)
import time


def validate_time_format(time_str):
    try:
        time.strptime(time_str, '%H:%M')
        return True
    except ValueError:
        return False
