// Menambahkan event listener ketika DOM sudah dimuat
document.addEventListener('DOMContentLoaded', function () {
    console.log("DOM fully loaded and parsed");

    // Panggil fungsi untuk memuat pengingat dari server
    loadReminders();
});

// Fungsi untuk memuat daftar pengingat dari server
function loadReminders() {
    fetch('/api/reminders')  // Mengambil data dari API endpoint
        .then(response => response.json())
        .then(data => {
            // Temukan elemen tbody dari tabel
            const tbody = document.querySelector('#reminderTable tbody');
            
            // Kosongkan isi tabel sebelum menambah pengingat baru
            tbody.innerHTML = '';

            // Iterasi melalui data dan tambahkan setiap pengingat ke dalam tabel
            data.forEach(reminder => {
                const row = document.createElement('tr');

                // Buat elemen <td> untuk setiap kolom (nama obat, waktu, durasi)
                const medicineCell = document.createElement('td');
                const timeCell = document.createElement('td');
                const durationCell = document.createElement('td');
                const actionCell = document.createElement('td');

                // Masukkan data ke dalam elemen td
                medicineCell.textContent = reminder.medicine;
                timeCell.textContent = reminder.time;
                durationCell.textContent = reminder.duration;

                // Tambahkan tombol hapus di kolom aksi
                const deleteButton = document.createElement('button');
                deleteButton.textContent = "delete";
                deleteButton.className = "delete-btn";
                deleteButton.onclick = () => deleteReminder(reminder.id);

                actionCell.appendChild(deleteButton);

                // Tambahkan <td> ke dalam <tr>
                row.appendChild(medicineCell);
                row.appendChild(timeCell);
                row.appendChild(durationCell);
                row.appendChild(actionCell);

                // Tambahkan <tr> ke dalam <tbody>
                tbody.appendChild(row);
            });
        })
        .catch(error => {
            console.error('Error fetching reminders:', error);
        });
}

// Fungsi untuk menghapus pengingat
function deleteReminder(id) {
    fetch('/api/reminders/${id}', {  // Menghapus pengingat dengan ID tertentu
        method: 'DELETE'
    })
    .then(response => {
        if (response.ok) {
            alert('Reminder successfully deleted');
            loadReminders();  // Muat ulang daftar pengingat setelah penghapusan
        } else {
            alert('failed delated reminder');
        }
    })
    .catch(error => {
        console.error('Error deleting reminder:', error);
    });
}