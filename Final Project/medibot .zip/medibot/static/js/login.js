document.getElementById("loginBtn").addEventListener("click", function() {
    document.getElementById("loginForm").classList.add("active");
    document.getElementById("signUpForm").classList.remove("active");
    this.classList.add("active");
    document.getElementById("signUpBtn").classList.remove("active");
});

document.getElementById("signUpBtn").addEventListener("click", function() {
    document.getElementById("signUpForm").classList.add("active");
    document.getElementById("loginForm").classList.remove("active");
    this.classList.add("active");
    document.getElementById("loginBtn").classList.remove("active");
});

document.getElementById("loginForm").addEventListener("submit", function(e) {
    e.preventDefault();
    let username = document.getElementById("loginUsername").value;
    let password = document.getElementById("loginPassword").value;
    alert("Login successful with Username: " + username);
});

document.getElementById("loginForm").addEventListener("submit", function(e) {
    e.preventDefault();
    let username = document.getElementById("loginUsername").value;
    let password = document.getElementById("loginPassword").value;
    
    if (username === "user" && password === "123") {
        window.location.href = "index.html";  
    } else {
        alert("Username atau password salah!");
    }
});


document.getElementById("signUpForm").addEventListener("submit", function(e) {
    e.preventDefault();
    let username = document.getElementById("signUpUsername").value;
    let email = document.getElementById("signUpEmail").value;
    let password = document.getElementById("signUpPassword").value;
    alert("Sign Up successful with Username: " + username + " and Email: " + email);
});
