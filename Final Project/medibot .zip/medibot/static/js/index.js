document.addEventListener("DOMContentLoaded", () => {
    const setScheduleButton = document.createElement("button");
    setScheduleButton.textContent = "Set Schedule";
    setScheduleButton.className = "sidebar-btn";
    // Arahkan ke halaman set schedule (index.html ke reminder.html)
    setScheduleButton.onclick = () => {
      window.location.href = 'reminder.html';  // Ganti dengan halaman set schedule Anda
    };
  
    const scheduleListButton = document.createElement("button");
    scheduleListButton.textContent = "Schedule List";
    scheduleListButton.className = "sidebar-btn";
    // Arahkan ke halaman daftar jadwal (index.html ke list.html)
    scheduleListButton.onclick = () => {
      window.location.href = 'list.html';  // Ganti dengan halaman daftar jadwal Anda
    };
  
    const logOutButton = document.querySelector(".sidebar button");
    logOutButton.textContent = "Log out";
    // Fungsi untuk keluar (misalnya arahkan ke halaman login atau berikan alert)
    logOutButton.onclick = () => {
      alert("Logging out");
      // Jika Anda memiliki halaman login, arahkan ke halaman login
      window.location.href = 'login.html';  // Ganti dengan halaman login Anda
    };
  
    const sidebar = document.querySelector(".sidebar");
    // Sisipkan tombol "Set Schedule" dan "Schedule List" sebelum tombol logout
    sidebar.insertBefore(setScheduleButton, logOutButton);
    sidebar.insertBefore(scheduleListButton, logOutButton);
  });
  