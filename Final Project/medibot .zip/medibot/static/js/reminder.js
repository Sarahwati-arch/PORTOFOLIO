// Fungsi untuk meminta izin notifikasi jika belum diberikan
if (Notification.permission === 'granted') {
    // Izin sudah diberikan, tampilkan notifikasi
    showNotification();
} else if (Notification.permission !== 'denied') {
    // Minta izin dari pengguna
    Notification.requestPermission().then(permission => {
        if (permission === 'granted') {
            showNotification();
        }
    });
}

// Fungsi untuk menampilkan notifikasi
function showNotification() {
    new Notification('Time to take your medication', {
        body: 'Don\'t forget to take your medication!',
        icon: '/static/images/notification-icon.jpg'  // Ganti dengan path ke ikon yang kamu pilih
    });
}


// Fungsi untuk menangani pengiriman form reminder
document.getElementById('reminderForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the form from reloading the page

    const medicine = document.getElementById('medicine').value;
    const time = document.getElementById('time').value;
    const duration = document.getElementById('duration').value;

    // Create data object to send to the backend
    const data = {
        medicine: medicine,
        time: time,
        duration: duration
    };

    // Send data to the server using fetch API
    fetch('/api/reminder', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(data => {
        if (data.message === 'Reminder added successfully') {
            // Notifikasi ketika reminder berhasil ditambahkan
            showNotification(data.reminder);

            alert('Reminder added successfully!');
            window.location.href = '/list'; // Redirect to the reminder list page
        } else {
            alert('There was an error while saving the reminder.');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Network error occurred.');
    });
});
