from flask import Blueprint, request, jsonify, render_template
from .models import Reminder
from .database import db

reminder_routes = Blueprint('reminder_routes', __name__)

# Route for getting all reminders
@reminder_routes.route('/api/reminders', methods=['GET'])
def get_reminders():
    reminders = Reminder.query.all()
    return jsonify([{
        'id': r.id,
        'medicine': r.medicine,
        'time': r.time,
        'duration': r.duration
    } for r in reminders])

# Route for adding a new reminder
@reminder_routes.route('/api/reminder', methods=['POST'])
def add_reminder():
    data = request.json
    # Make sure to validate that data is coming through correctly
    if not data or 'medicine' not in data or 'time' not in data or 'duration' not in data:
        return jsonify({'message': 'Invalid data'}), 400
    
    new_reminder = Reminder(
        medicine=data['medicine'],
        time=data['time'],
        duration=data['duration']
    )
    
    try:
        db.session.add(new_reminder)
        db.session.commit()
        return jsonify({'message': 'Reminder added successfully'}), 201
    except Exception as e:
        return jsonify({'message': f'Error: {str(e)}'}), 500


# Route for deleting a reminder by ID
@reminder_routes.route('/api/reminder/<int:id>', methods=['DELETE'])
def delete_reminder(id):
    reminder = Reminder.query.get(id)
    if reminder:
        db.session.delete(reminder)
        db.session.commit()
        return jsonify({'message': 'Reminder deleted successfully'})
    return jsonify({'message': 'Reminder not found'}), 404

# Route for getting a reminder by ID
@reminder_routes.route('/reminder/<int:id>', methods=['GET'])
def edit_reminder(id):
    reminder = Reminder.query.get(id)
    if reminder:
        return jsonify({'id': reminder.id, 'medicine': reminder.medicine, 'time': reminder.time, 'duration': reminder.duration})
    return jsonify({'message': 'Reminder not found'}), 404

# Route to show the reminder page (no `/api` prefix here)
@reminder_routes.route('/reminder', methods=['GET'])
def reminder_page():
    return render_template('reminder.html')

# Route to show the list of reminders page (no `/api` prefix here)
@reminder_routes.route('/list', methods=['GET'])
def list_page():
    return render_template('list.html')
