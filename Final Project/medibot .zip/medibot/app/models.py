from .database import db

class Reminder(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    medicine = db.Column(db.String(100), nullable=False)
    time = db.Column(db.String(10), nullable=False)
    duration = db.Column(db.Integer, nullable=False)


    def __repr__(self):
        return f'<Reminder {self.medicine} at {self.time}>'
