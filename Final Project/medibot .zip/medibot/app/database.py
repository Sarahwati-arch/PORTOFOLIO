from flask_sqlalchemy import SQLAlchemy

# Membuat instance SQLAlchemy untuk digunakan dalam aplikasi
db = SQLAlchemy()
