from flask import Flask
from .database import db
from .routes import reminder_routes

def create_app():
    # Inisialisasi aplikasi Flask
    app = Flask(__name__)
    
    # Konfigurasi database (menggunakan SQLite untuk kemudahan)
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///my_database.db'  # Lokasi database SQLite
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False  # Nonaktifkan pelacakan perubahan objek (untuk efisiensi)

    # Inisialisasi database
    db.init_app(app)

    # Mendaftarkan blueprint untuk rute pengingat
    app.register_blueprint(reminder_routes)

    return app
