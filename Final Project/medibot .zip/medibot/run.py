from app import create_app
import os

# Create an instance of the application
app = create_app()

if __name__ == '__main__':
    # Run the application, ensuring it's accessible via the local network
    app.run(debug=True, host='0.0.0.0', port=5000)

    # Print the current working directory and the database URI for debugging
    print("Flask is running in:", os.getcwd())
    print("Database URI:", app.config.get('SQLALCHEMY_DATABASE_URI', 'No database configured'))
