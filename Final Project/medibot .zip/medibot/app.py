from flask import Flask, render_template
from app.routes import reminder_routes  # Pastikan ini benar
from app.database import db  # Import db dari file database.py
from app.models import Reminder  # Import model Reminder

app = Flask(__name__)

# Konfigurasi untuk koneksi ke database
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///reminders.db'  # Atau sesuaikan dengan database yang Anda gunakan
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Inisialisasi db dengan aplikasi Flask
db.init_app(app)

# Register blueprint tanpa url_prefix, atau sesuaikan jika perlu
app.register_blueprint(reminder_routes)

@app.before_request
def create_tables():
    # Membuat tabel hanya saat permintaan pertama kali diterima
    with app.app_context():
        db.create_all()  # Ini akan membuat semua tabel yang terdefinisi di model, termasuk Reminder

@app.route("/")
def home():
    # Render halaman index.html sebagai halaman utama
    return render_template("index.html")

@app.route("/list")
def list_reminders():
    # Ambil semua pengingat dari database
    reminders = Reminder.query.all()
    print(reminders)  # Debug: Print data reminders
    return render_template("list.html", reminders=reminders)


# Print semua route yang terdaftar (untuk debug)
if __name__ == "__main__":
    # Print routes untuk membantu debugging jika diperlukan
    for rule in app.url_map.iter_rules():
        print(rule)
    app.run(debug=True)
