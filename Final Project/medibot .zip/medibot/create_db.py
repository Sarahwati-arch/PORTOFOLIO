from app import create_app
from app.database import db
from app.models import Reminder

# Membuat aplikasi Flask
app = create_app()

with app.app_context():
    # Menambahkan pengingat baru
    new_reminder = Reminder(medicine='Paracetamol', time='08:00', duration=7)
    db.session.add(new_reminder)
    db.session.commit()

    # Mengambil semua pengingat
    reminders = Reminder.query.all()
    for reminder in reminders:
        print(reminder)
